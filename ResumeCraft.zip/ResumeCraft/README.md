# ResumeCraft — Full Stack (Deliverable 2)

A Vue 3 + Express + MongoDB resume builder. The client is the same
ResumeCraft frontend from Deliverable 1; the only change is that it
now saves to MongoDB through an Express API instead of Local Storage.

```
ResumeCraft/
  client/   Vue 3 + Vite frontend
  server/   Express + MongoDB backend
```

## Running the project

You need two terminals — one for the server, one for the client.

**1. Start the server**

```bash
cd server
npm install
cp .env.example .env
# open .env and paste in your MongoDB Atlas connection string
npm run dev
```

You should see:

```
Connected to MongoDB Atlas.
Server is running on http://localhost:5000
```

**2. Start the client**

```bash
cd client
npm install
npm run dev
```

Open the URL Vite prints (usually `http://localhost:5173`). The app
talks to the server at `http://localhost:5000/api/resumes`.

## What changed from Deliverable 1

- `client/src/services/api.js` — new file. Small `fetch()` helpers for
  talking to the Express API (`getResumes`, `createResume`,
  `updateResume`).
- `client/src/composables/useResumeData.js` — same public functions as
  before (`updatePersonalInfo`, `addEducation`, `updateEducation`,
  etc.). Internally, `saveToServer()` replaced the old `persist()`
  function, and `loadResumeData()` now fetches from the API instead of
  reading `localStorage`.
- `client/src/App.vue` — calls `loadResumeData()` in `onMounted()` so
  the app asks the server for the saved resume as soon as it starts.
- Every Vue component (forms, views, `NavBar`, `ResumePreview`) is
  untouched — they never talked to Local Storage directly, so they
  don't need to know the data now comes from MongoDB either.

## Backend structure

```
server/
  server.js                    Creates the app, loads middleware, connects
                                the database, starts listening.
  config/db.js                 Connects to MongoDB Atlas with Mongoose.
  models/Resume.js             Mongoose schema — matches resumeData exactly.
  controllers/resumeController.js  Business logic: create, read, update, delete.
  routes/resumeRoutes.js       Maps HTTP requests to controller functions.
  .env.example                 Template for your own .env file.
```

### Request flow

```
Vue component
  ↓ (emit)
BuilderView
  ↓ (calls a composable function, e.g. updatePersonalInfo)
useResumeData.js
  ↓ (fetch via services/api.js)
Express route (routes/resumeRoutes.js)
  ↓
Controller (controllers/resumeController.js)
  ↓
Mongoose model (models/Resume.js)
  ↓
MongoDB Atlas
  ↓ (updated document comes back)
Controller sends the response
  ↓
useResumeData.js updates resumeData
  ↓ (Props)
Vue components re-render — Builder form and Preview both reflect it
```

## API

| Method | Route              | Does what                                  |
|--------|---------------------|---------------------------------------------|
| GET    | /api/resumes         | Returns every stored resume                 |
| POST   | /api/resumes         | Creates a new resume                        |
| GET    | /api/resumes/:id     | Returns one resume by id                    |
| PUT    | /api/resumes/:id     | Replaces a resume with the latest data      |
| DELETE | /api/resumes/:id     | Deletes a resume                            |

The app only ever keeps one resume: on first load it asks for
`GET /api/resumes`, uses the first one it finds (or creates one if
none exists), and every edit after that goes out as a
`PUT /api/resumes/:id` with the full, updated resume.
