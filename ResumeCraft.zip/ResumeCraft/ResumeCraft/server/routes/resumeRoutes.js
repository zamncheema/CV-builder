const express = require('express')
const router = express.Router()

const {
  createResume,
  getAllResumes,
  getResumeById,
  updateResume,
  deleteResume
} = require('../controllers/resumeController')

// /api/resumes
router.route('/').get(getAllResumes).post(createResume)

// /api/resumes/:id
router.route('/:id').get(getResumeById).put(updateResume).delete(deleteResume)

module.exports = router
