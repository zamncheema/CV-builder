const Resume = require('../models/Resume')

// Create a brand new resume in MongoDB.
// Called once, the first time someone opens the app and no resume
// exists yet — after that, the app just keeps updating the same one.
async function createResume(req, res) {
  try {
    const resume = await Resume.create(req.body)
    res.status(201).json(resume)
  } catch (error) {
    res.status(400).json({ message: 'Could not create the resume.', error: error.message })
  }
}

// Return every resume that's stored in the database.
// Our frontend only ever keeps one resume, so in practice this list
// will usually contain a single item — the app just reads the first
// one it gets back.
async function getAllResumes(req, res) {
  try {
    const resumes = await Resume.find().sort({ createdAt: 1 })
    res.status(200).json(resumes)
  } catch (error) {
    res.status(500).json({ message: 'Could not load resumes.', error: error.message })
  }
}

// Find one resume using its MongoDB id.
async function getResumeById(req, res) {
  try {
    const resume = await Resume.findById(req.params.id)

    if (!resume) {
      return res.status(404).json({ message: 'No resume found with that id.' })
    }

    res.status(200).json(resume)
  } catch (error) {
    res.status(400).json({ message: 'That id is not valid.', error: error.message })
  }
}

// Replace the stored resume with whatever the frontend just sent.
// The frontend always sends the full resume object (personal,
// education, experience, skills together), so we simply overwrite
// the existing document with it and hand back the updated version.
async function updateResume(req, res) {
  try {
    const resume = await Resume.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true
    })

    if (!resume) {
      return res.status(404).json({ message: 'No resume found with that id.' })
    }

    res.status(200).json(resume)
  } catch (error) {
    res.status(400).json({ message: 'Could not save the resume.', error: error.message })
  }
}

// Delete a resume completely. Not used by the current UI, but kept
// here so the API offers full CRUD, the way a real backend should.
async function deleteResume(req, res) {
  try {
    const resume = await Resume.findByIdAndDelete(req.params.id)

    if (!resume) {
      return res.status(404).json({ message: 'No resume found with that id.' })
    }

    res.status(200).json({ message: 'Resume deleted successfully.' })
  } catch (error) {
    res.status(400).json({ message: 'Could not delete the resume.', error: error.message })
  }
}

module.exports = {
  createResume,
  getAllResumes,
  getResumeById,
  updateResume,
  deleteResume
}
