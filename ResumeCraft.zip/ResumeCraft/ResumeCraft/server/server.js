// Load environment variables (like MONGODB_URI and PORT) before
// anything else runs, so the rest of this file can just use them.
require('dotenv').config()

const express = require('express')
const cors = require('cors')

const connectDatabase = require('./config/db')
const resumeRoutes = require('./routes/resumeRoutes')

const app = express()

// Allow our Vue frontend (running on a different port) to send
// requests to this server.
app.use(cors())

// Parse incoming JSON bodies so req.body works inside our routes.
app.use(express.json())

// Every request that starts with /api/resumes is handled by this
// router. server.js doesn't need to know what happens inside it.
app.use('/api/resumes', resumeRoutes)

const PORT = process.env.PORT || 5000

// Connect to MongoDB first, and only start listening for requests
// once that connection actually succeeds. This way the server never
// accepts a request it can't properly handle.
connectDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`)
    })
  })
  .catch((error) => {
    console.error('Could not start the server because MongoDB failed to connect.')
    console.error(error.message)
    process.exit(1)
  })
