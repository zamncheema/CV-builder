const mongoose = require('mongoose')

// This file has one job: connect to MongoDB. server.js calls this
// function and waits for it to finish before it starts accepting
// requests. Keeping the connection logic here (instead of inside
// server.js) means server.js doesn't need to know anything about
// how MongoDB works — it just calls connectDatabase() and trusts it.
async function connectDatabase() {
  const connectionString = process.env.MONGODB_URI

  if (!connectionString) {
    throw new Error('MONGODB_URI is missing. Add it to server/.env before starting the server.')
  }

  await mongoose.connect(connectionString)
  console.log('Connected to MongoDB Atlas.')
}

module.exports = connectDatabase
