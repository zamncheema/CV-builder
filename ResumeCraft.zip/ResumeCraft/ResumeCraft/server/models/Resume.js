const mongoose = require('mongoose')

// -----------------------------------------------------------------
// PERSONAL INFORMATION
// This matches resumeData.personal in useResumeData.js field for
// field. It's embedded directly in the resume instead of its own
// collection, because a resume can never exist without it — there's
// no situation where we'd want to look up "personal info" on its own.
// -----------------------------------------------------------------
const personalSchema = new mongoose.Schema(
  {
    fullName: { type: String, trim: true, default: '' },
    jobTitle: { type: String, trim: true, default: '' },
    email: { type: String, trim: true, default: '' },
    phone: { type: String, trim: true, default: '' },
    location: { type: String, trim: true, default: '' },
    summary: { type: String, trim: true, default: '' }
  },
  { _id: false }
)

// -----------------------------------------------------------------
// EDUCATION
// Each object here matches one entry from resumeData.education[].
// We keep the frontend's own "id" field (a plain number) instead of
// relying on MongoDB's automatic _id, since that's what the Vue
// components already use to tell entries apart in v-for and to know
// which entry to update or remove.
// -----------------------------------------------------------------
const educationSchema = new mongoose.Schema(
  {
    id: { type: Number, required: true },
    school: { type: String, trim: true, default: '' },
    degree: { type: String, trim: true, default: '' },
    field: { type: String, trim: true, default: '' },
    startDate: { type: String, trim: true, default: '' },
    endDate: { type: String, trim: true, default: '' }
  },
  { _id: false }
)

// -----------------------------------------------------------------
// EXPERIENCE
// Matches one entry from resumeData.experience[].
// -----------------------------------------------------------------
const experienceSchema = new mongoose.Schema(
  {
    id: { type: Number, required: true },
    company: { type: String, trim: true, default: '' },
    role: { type: String, trim: true, default: '' },
    startDate: { type: String, trim: true, default: '' },
    endDate: { type: String, trim: true, default: '' },
    description: { type: String, trim: true, default: '' }
  },
  { _id: false }
)

// -----------------------------------------------------------------
// SKILLS
// Matches one entry from resumeData.skills[]. "level" defaults to
// Intermediate because that's also what addSkill() in the composable
// uses when a new skill is created.
// -----------------------------------------------------------------
const skillSchema = new mongoose.Schema(
  {
    id: { type: Number, required: true },
    name: { type: String, trim: true, default: '' },
    level: { type: String, trim: true, default: 'Intermediate' }
  },
  { _id: false }
)

// -----------------------------------------------------------------
// RESUME
// This is the document that actually gets saved in MongoDB. It's
// just the four pieces above, grouped the same way the frontend
// already groups them.
//
// timestamps: true adds createdAt and updatedAt automatically. We're
// not showing these anywhere in the UI, but they're useful while
// building and debugging — they let us check in MongoDB Atlas that a
// save request actually went through and when.
// -----------------------------------------------------------------
const resumeSchema = new mongoose.Schema(
  {
    personal: { type: personalSchema, default: () => ({}) },
    education: { type: [educationSchema], default: [] },
    experience: { type: [experienceSchema], default: [] },
    skills: { type: [skillSchema], default: [] }
  },
  { timestamps: true }
)

module.exports = mongoose.model('Resume', resumeSchema)
