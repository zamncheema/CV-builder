<script setup>
// Responsibility: introduce the product and send the user to the Builder.
// Owns no resume state — it's a static landing page.
import { onMounted } from 'vue'

onMounted(() => {
  document.title = 'ResumeCraft – Professional Resume Builder'
})
</script>

<template>
  <section class="hero">
    <div class="container hero-inner">
      <p class="eyebrow">Professional Resume Builder</p>
      <h1 class="hero-title">
        Write a resume that reads<br />as well as it looks.
      </h1>
      <p class="hero-sub">
        Fill in one clean form, watch a polished resume take shape beside it,
        and export it the moment it's ready. No sign-up, no clutter — your
        details stay saved right in this browser.
      </p>
      <div class="hero-actions">
        <RouterLink to="/builder" class="btn btn-primary">Start building</RouterLink>
        <RouterLink to="/preview" class="btn btn-secondary">View my resume</RouterLink>
      </div>
    </div>

    <div class="hero-showcase container">
      <div class="showcase-card">
        <div class="showcase-line showcase-line--title"></div>
        <div class="showcase-line showcase-line--sub"></div>
        <div class="showcase-divider"></div>
        <div class="showcase-block">
          <div class="showcase-line showcase-line--label"></div>
          <div class="showcase-line showcase-line--text"></div>
          <div class="showcase-line showcase-line--text short"></div>
        </div>
        <div class="showcase-block">
          <div class="showcase-line showcase-line--label"></div>
          <div class="showcase-line showcase-line--text"></div>
          <div class="showcase-line showcase-line--text short"></div>
        </div>
      </div>
    </div>

    <div class="container steps">
      <div class="step">
        <span class="step-number">01</span>
        <h3>Add your details</h3>
        <p>Personal info, education, experience, and skills — one section at a time.</p>
      </div>
      <div class="step">
        <span class="step-number">02</span>
        <h3>Watch it take shape</h3>
        <p>Every change updates the live preview instantly, so you always know how it reads.</p>
      </div>
      <div class="step">
        <span class="step-number">03</span>
        <h3>Export and apply</h3>
        <p>Print straight to PDF from the preview page when your resume is ready to send.</p>
      </div>
    </div>
  </section>
</template>

<style scoped>
.hero {
  padding-bottom: var(--space-8);
}

.hero-inner {
  padding-top: var(--space-8);
  padding-bottom: var(--space-7);
  max-width: 760px;
}

.eyebrow {
  font-size: 0.8rem;
  font-weight: 600;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-accent);
  margin-bottom: var(--space-4);
}

.hero-title {
  font-size: 2.75rem;
  line-height: 1.15;
  letter-spacing: -0.01em;
  margin-bottom: var(--space-5);
}

.hero-sub {
  font-size: 1.05rem;
  color: var(--color-ink-soft);
  max-width: 560px;
  margin-bottom: var(--space-6);
}

.hero-actions {
  display: flex;
  gap: var(--space-3);
}

/* Abstract resume mock used purely as a visual signature —
   built from CSS blocks, no image assets required. */
.hero-showcase {
  margin-bottom: var(--space-8);
}

.showcase-card {
  max-width: 640px;
  margin: 0 auto;
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-lg);
  padding: var(--space-6) var(--space-7);
}

.showcase-line {
  background: var(--color-border);
  border-radius: 4px;
  height: 10px;
}

.showcase-line--title {
  width: 45%;
  height: 18px;
  background: var(--color-ink);
  opacity: 0.85;
  margin-bottom: var(--space-2);
}

.showcase-line--sub {
  width: 30%;
  background: var(--color-accent);
  opacity: 0.5;
}

.showcase-divider {
  height: 1px;
  background: var(--color-border);
  margin: var(--space-5) 0;
}

.showcase-block {
  margin-bottom: var(--space-4);
}

.showcase-line--label {
  width: 22%;
  background: var(--color-accent);
  opacity: 0.35;
  margin-bottom: var(--space-3);
}

.showcase-line--text {
  width: 90%;
  margin-bottom: var(--space-2);
}

.showcase-line--text.short {
  width: 60%;
}

.steps {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: var(--space-6);
}

.step-number {
  font-family: var(--font-display);
  font-size: 1rem;
  color: var(--color-accent);
  display: block;
  margin-bottom: var(--space-2);
}

.step h3 {
  font-size: 1.05rem;
  margin-bottom: var(--space-2);
}

.step p {
  color: var(--color-slate);
  font-size: 0.92rem;
  line-height: 1.6;
}

@media (max-width: 780px) {
  .hero-title {
    font-size: 2.1rem;
  }
  .steps {
    grid-template-columns: 1fr;
  }
  .showcase-card {
    padding: var(--space-5);
  }
}
</style>
