<script setup>
import { onMounted } from 'vue'
import { useResumeData } from '../composables/useResumeData'
import PersonalInfoForm from '../components/PersonalInfoForm.vue'
import EducationForm from '../components/EducationForm.vue'
import ExperienceForm from '../components/ExperienceForm.vue'
import SkillsForm from '../components/SkillsForm.vue'
import ResumePreview from '../components/ResumePreview.vue'

// BuilderView owns nothing itself — it reads and writes through the
// shared composable, which is the single source of truth. Every form
// below receives a slice of resumeData as a Prop and reports changes
// back up through an Emit, which this view forwards straight into the
// composable's update functions.
const {
  resumeData,
  updatePersonalInfo,
  addEducation,
  updateEducation,
  removeEducation,
  addExperience,
  updateExperience,
  removeExperience,
  addSkill,
  updateSkill,
  removeSkill
} = useResumeData()

onMounted(() => {
  document.title = 'Builder – ResumeCraft'
})
</script>

<template>
  <div class="builder container">
    <div class="builder-intro">
      <h1>Build your resume</h1>
      <p>Fill in each section — the preview on the right updates as you type.</p>
    </div>

    <div class="builder-layout">
      <div class="builder-forms">
        <PersonalInfoForm :personal-info="resumeData.personal" @update="updatePersonalInfo" />

        <ExperienceForm
          :entries="resumeData.experience"
          @add-entry="addExperience"
          @update-entry="updateExperience"
          @remove-entry="removeExperience"
        />

        <EducationForm
          :entries="resumeData.education"
          @add-entry="addEducation"
          @update-entry="updateEducation"
          @remove-entry="removeEducation"
        />

        <SkillsForm
          :entries="resumeData.skills"
          @add-entry="addSkill"
          @update-entry="updateSkill"
          @remove-entry="removeSkill"
        />

        <RouterLink to="/preview" class="btn btn-primary builder-cta">
          Go to full preview →
        </RouterLink>
      </div>

      <aside class="builder-preview">
        <div class="preview-sticky">
          <p class="preview-label">Live preview</p>
          <ResumePreview :resume="resumeData" />
        </div>
      </aside>
    </div>
  </div>
</template>

<style scoped>
.builder {
  padding: var(--space-6) var(--space-5) var(--space-8);
}

.builder-intro {
  margin-bottom: var(--space-6);
}

.builder-intro h1 {
  font-size: 1.9rem;
  margin-bottom: var(--space-2);
}

.builder-intro p {
  color: var(--color-slate);
  font-size: 0.95rem;
}

.builder-layout {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 0.9fr);
  gap: var(--space-6);
  align-items: start;
}

.builder-forms {
  display: flex;
  flex-direction: column;
  gap: var(--space-5);
}

.builder-cta {
  align-self: flex-start;
  margin-top: var(--space-2);
}

.builder-preview {
  position: sticky;
  top: 92px;
}

.preview-sticky {
  transform: scale(0.86);
  transform-origin: top center;
}

.preview-label {
  font-size: 0.75rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-slate);
  text-align: center;
  margin-bottom: var(--space-3);
}

@media (max-width: 980px) {
  .builder-layout {
    grid-template-columns: 1fr;
  }
  .builder-preview {
    position: static;
  }
  .preview-sticky {
    transform: none;
  }
}
</style>
