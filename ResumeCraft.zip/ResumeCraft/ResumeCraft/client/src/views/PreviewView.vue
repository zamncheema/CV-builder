<script setup>
import { onMounted } from 'vue'
import { useResumeData } from '../composables/useResumeData'
import ResumePreview from '../components/ResumePreview.vue'

const { resumeData } = useResumeData()

onMounted(() => {
  document.title = 'Preview – ResumeCraft'
})

function handlePrint() {
  window.print()
}
</script>

<template>
  <div class="preview-page container">
    <div class="preview-toolbar">
      <div>
        <h1>Your resume</h1>
        <p>This is exactly how your resume will look when exported.</p>
      </div>
      <div class="toolbar-actions">
        <RouterLink to="/builder" class="btn btn-secondary">Edit details</RouterLink>
        <button type="button" class="btn btn-primary" @click="handlePrint">Export as PDF</button>
      </div>
    </div>

    <ResumePreview :resume="resumeData" />
  </div>
</template>

<style scoped>
.preview-page {
  padding: var(--space-6) var(--space-5) var(--space-8);
}

.preview-toolbar {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
  margin-bottom: var(--space-6);
  flex-wrap: wrap;
}

.preview-toolbar h1 {
  font-size: 1.9rem;
  margin-bottom: var(--space-2);
}

.preview-toolbar p {
  color: var(--color-slate);
  font-size: 0.95rem;
}

.toolbar-actions {
  display: flex;
  gap: var(--space-3);
}

@media (max-width: 560px) {
  .toolbar-actions {
    width: 100%;
  }
  .toolbar-actions .btn {
    flex: 1;
  }
}
</style>
