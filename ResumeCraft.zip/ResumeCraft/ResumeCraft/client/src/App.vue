<script setup>
// App.vue's only responsibilities are the page shell (NavBar + routed
// page) and kicking off the very first load of the resume.
//
// Loading now means asking our Express backend for data over the
// network, which takes a moment to resolve — unlike Local Storage,
// it can't be read synchronously the instant this file is imported.
// So we ask for it here, once, when the app actually mounts. Every
// form already reads its values straight from resumeData through
// Props, so as soon as the response arrives and resumeData updates,
// the screen updates with it automatically.
import { onMounted } from 'vue'
import NavBar from './components/NavBar.vue'
import { useResumeData } from './composables/useResumeData'

const { loadResumeData } = useResumeData()

onMounted(() => {
  loadResumeData()
})
</script>

<template>
  <div class="app-shell">
    <NavBar />
    <main class="app-main">
      <RouterView />
    </main>
  </div>
</template>

<style scoped>
.app-shell {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

.app-main {
  flex: 1;
}
</style>
