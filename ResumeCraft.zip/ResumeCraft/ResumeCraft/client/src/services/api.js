// A handful of small functions for talking to our Express backend.
// Each one sends one HTTP request and hands back the parsed JSON.
// Nothing in here knows about Vue — it's plain fetch calls, so any
// part of the app could reuse it later if needed.

const BASE_URL = 'http://localhost:5000/api/resumes'

// Ask the backend for every stored resume. Our app only ever keeps
// one, so the composable just uses the first item in the list.
async function getResumes() {
  const response = await fetch(BASE_URL)

  if (!response.ok) {
    throw new Error('Could not load the resume from the server.')
  }

  return response.json()
}

// Create the very first resume, the first time someone opens the app
// and MongoDB doesn't have one yet.
async function createResume(resumeData) {
  const response = await fetch(BASE_URL, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(resumeData)
  })

  if (!response.ok) {
    throw new Error('Could not create a resume on the server.')
  }

  return response.json()
}

// Save the latest changes to an existing resume.
async function updateResume(id, resumeData) {
  const response = await fetch(`${BASE_URL}/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(resumeData)
  })

  if (!response.ok) {
    throw new Error('Could not save changes to the server.')
  }

  return response.json()
}

export default { getResumes, createResume, updateResume }
