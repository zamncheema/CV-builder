<script setup>
// RESPONSIBILITY: collect personal information. Nothing else.
//
// This component never touches the shared resume state directly.
// It receives the current values through a Prop, and every time the
// user types, it emits an 'update' event carrying the full, updated
// object. The parent (BuilderView) listens for that event and is the
// only place that actually changes the stored data. Because every
// input reads its value straight from the prop, the field on screen
// always reflects the parent's real state.

const props = defineProps({
  personalInfo: {
    type: Object,
    required: true
  }
})

const emit = defineEmits(['update'])

function handleFieldChange(field, value) {
  emit('update', { ...props.personalInfo, [field]: value })
}
</script>

<template>
  <div class="card form-card">
    <h2 class="form-title">Personal Information</h2>
    <p class="form-hint">This appears at the top of your resume.</p>

    <div class="field-row">
      <div class="field-group">
        <label for="fullName">Full name</label>
        <input
          id="fullName"
          type="text"
          placeholder="Jordan Reyes"
          :value="personalInfo.fullName"
          @input="handleFieldChange('fullName', $event.target.value)"
        />
      </div>
      <div class="field-group">
        <label for="jobTitle">Target job title</label>
        <input
          id="jobTitle"
          type="text"
          placeholder="Frontend Developer"
          :value="personalInfo.jobTitle"
          @input="handleFieldChange('jobTitle', $event.target.value)"
        />
      </div>
    </div>

    <div class="field-row">
      <div class="field-group">
        <label for="email">Email</label>
        <input
          id="email"
          type="email"
          placeholder="jordan@email.com"
          :value="personalInfo.email"
          @input="handleFieldChange('email', $event.target.value)"
        />
      </div>
      <div class="field-group">
        <label for="phone">Phone</label>
        <input
          id="phone"
          type="tel"
          placeholder="+92 300 1234567"
          :value="personalInfo.phone"
          @input="handleFieldChange('phone', $event.target.value)"
        />
      </div>
    </div>

    <div class="field-group">
      <label for="location">Location</label>
      <input
        id="location"
        type="text"
        placeholder="Lahore, Pakistan"
        :value="personalInfo.location"
        @input="handleFieldChange('location', $event.target.value)"
      />
    </div>

    <div class="field-group">
      <label for="summary">Professional summary</label>
      <textarea
        id="summary"
        rows="4"
        placeholder="A short, confident summary of who you are and what you're looking for."
        :value="personalInfo.summary"
        @input="handleFieldChange('summary', $event.target.value)"
      ></textarea>
    </div>
  </div>
</template>

<style scoped>
.form-card {
  padding: var(--space-6);
}

.form-title {
  font-size: 1.2rem;
  margin-bottom: var(--space-1);
}

.form-hint {
  color: var(--color-slate);
  font-size: 0.85rem;
  margin-bottom: var(--space-5);
}
</style>
