<script setup>
// Responsibility: navigation only. It owns no resume data.
</script>

<template>
  <header class="navbar">
    <div class="navbar-inner container">
      <RouterLink to="/" class="brand">
        <span class="brand-mark">R</span>
        <span class="brand-name">ResumeCraft</span>
      </RouterLink>

      <nav class="nav-links">
        <RouterLink to="/" class="nav-link">Home</RouterLink>
        <RouterLink to="/builder" class="nav-link">Builder</RouterLink>
        <RouterLink to="/preview" class="nav-link">Preview</RouterLink>
      </nav>
    </div>
  </header>
</template>

<style scoped>
.navbar {
  background: var(--color-surface);
  border-bottom: 1px solid var(--color-border);
  position: sticky;
  top: 0;
  z-index: 20;
}

.navbar-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 68px;
}

.brand {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.brand-mark {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--color-accent);
  color: #fff;
  font-family: var(--font-display);
  font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
}

.brand-name {
  font-family: var(--font-display);
  font-weight: 600;
  font-size: 1.15rem;
  color: var(--color-ink);
}

.nav-links {
  display: flex;
  gap: var(--space-6);
}

.nav-link {
  font-size: 0.92rem;
  font-weight: 500;
  color: var(--color-slate);
  padding: 6px 2px;
  border-bottom: 2px solid transparent;
  transition: color 0.15s ease, border-color 0.15s ease;
}

.nav-link:hover {
  color: var(--color-ink);
}

.nav-link.router-link-exact-active {
  color: var(--color-accent);
  border-color: var(--color-accent);
}

@media (max-width: 560px) {
  .nav-links {
    gap: var(--space-4);
  }
  .brand-name {
    display: none;
  }
}
</style>
