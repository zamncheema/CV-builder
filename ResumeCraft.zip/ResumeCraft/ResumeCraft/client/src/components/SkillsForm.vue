<script setup>
// RESPONSIBILITY: collect skills. Nothing else.
// Same Props-down / Emits-up pattern as the other list forms.

const props = defineProps({
  entries: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['add-entry', 'update-entry', 'remove-entry'])

const levels = ['Beginner', 'Intermediate', 'Advanced', 'Expert']

function handleFieldChange(entry, field, value) {
  emit('update-entry', entry.id, { ...entry, [field]: value })
}
</script>

<template>
  <div class="card form-card">
    <div class="form-header">
      <div>
        <h2 class="form-title">Skills</h2>
        <p class="form-hint">Tools, languages, and frameworks you're comfortable with.</p>
      </div>
      <button type="button" class="btn btn-secondary btn-sm" @click="emit('add-entry')">
        + Add skill
      </button>
    </div>

    <p v-if="entries.length === 0" class="empty-state">
      No skills added yet. Click "Add skill" to create your first entry.
    </p>

    <div v-for="entry in entries" :key="entry.id" class="skill-row">
      <input
        type="text"
        class="skill-name-input"
        placeholder="Vue.js"
        :value="entry.name"
        @input="handleFieldChange(entry, 'name', $event.target.value)"
      />
      <select
        class="skill-level-select"
        :value="entry.level"
        @change="handleFieldChange(entry, 'level', $event.target.value)"
      >
        <option v-for="level in levels" :key="level" :value="level">{{ level }}</option>
      </select>
      <button type="button" class="btn btn-ghost btn-sm" @click="emit('remove-entry', entry.id)">
        Remove
      </button>
    </div>
  </div>
</template>

<style scoped>
.form-card {
  padding: var(--space-6);
}

.form-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
  margin-bottom: var(--space-5);
}

.form-title {
  font-size: 1.2rem;
  margin-bottom: var(--space-1);
}

.form-hint {
  color: var(--color-slate);
  font-size: 0.85rem;
}

.empty-state {
  color: var(--color-slate);
  font-size: 0.88rem;
  background: var(--color-bg);
  border: 1px dashed var(--color-border);
  border-radius: var(--radius-sm);
  padding: var(--space-4);
  text-align: center;
}

.skill-row {
  display: grid;
  grid-template-columns: 1fr 160px auto;
  gap: var(--space-3);
  align-items: center;
  padding: var(--space-3) 0;
  border-top: 1px solid var(--color-border);
}

.skill-row:first-of-type {
  border-top: none;
}

.skill-name-input,
.skill-level-select {
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  padding: 9px 12px;
  background: var(--color-surface);
  color: var(--color-ink);
}

.skill-name-input:focus,
.skill-level-select:focus {
  border-color: var(--color-accent);
  box-shadow: 0 0 0 3px var(--color-accent-soft);
  outline: none;
}

@media (max-width: 560px) {
  .skill-row {
    grid-template-columns: 1fr;
  }
}
</style>
