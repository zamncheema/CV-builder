<script setup>
// RESPONSIBILITY: collect work experience details. Nothing else.
// Same Props-down / Emits-up pattern as EducationForm.

const props = defineProps({
  entries: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['add-entry', 'update-entry', 'remove-entry'])

function handleFieldChange(entry, field, value) {
  emit('update-entry', entry.id, { ...entry, [field]: value })
}
</script>

<template>
  <div class="card form-card">
    <div class="form-header">
      <div>
        <h2 class="form-title">Work Experience</h2>
        <p class="form-hint">Your roles, starting with the most recent.</p>
      </div>
      <button type="button" class="btn btn-secondary btn-sm" @click="emit('add-entry')">
        + Add experience
      </button>
    </div>

    <p v-if="entries.length === 0" class="empty-state">
      No experience added yet. Click "Add experience" to create your first entry.
    </p>

    <div v-for="entry in entries" :key="entry.id" class="entry-block">
      <div class="entry-header">
        <span class="entry-label">Experience entry</span>
        <button type="button" class="btn btn-ghost btn-sm" @click="emit('remove-entry', entry.id)">
          Remove
        </button>
      </div>

      <div class="field-row">
        <div class="field-group">
          <label>Company</label>
          <input
            type="text"
            placeholder="Systems Ltd."
            :value="entry.company"
            @input="handleFieldChange(entry, 'company', $event.target.value)"
          />
        </div>
        <div class="field-group">
          <label>Role / Title</label>
          <input
            type="text"
            placeholder="Frontend Developer Intern"
            :value="entry.role"
            @input="handleFieldChange(entry, 'role', $event.target.value)"
          />
        </div>
      </div>

      <div class="field-row">
        <div class="field-group">
          <label>Start date</label>
          <input
            type="text"
            placeholder="Jun 2025"
            :value="entry.startDate"
            @input="handleFieldChange(entry, 'startDate', $event.target.value)"
          />
        </div>
        <div class="field-group">
          <label>End date</label>
          <input
            type="text"
            placeholder="Present"
            :value="entry.endDate"
            @input="handleFieldChange(entry, 'endDate', $event.target.value)"
          />
        </div>
      </div>

      <div class="field-group">
        <label>Description</label>
        <textarea
          rows="3"
          placeholder="What did you build, improve, or ship in this role?"
          :value="entry.description"
          @input="handleFieldChange(entry, 'description', $event.target.value)"
        ></textarea>
      </div>
    </div>
  </div>
</template>

<style scoped>
.form-card {
  padding: var(--space-6);
}

.form-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
  margin-bottom: var(--space-5);
}

.form-title {
  font-size: 1.2rem;
  margin-bottom: var(--space-1);
}

.form-hint {
  color: var(--color-slate);
  font-size: 0.85rem;
}

.empty-state {
  color: var(--color-slate);
  font-size: 0.88rem;
  background: var(--color-bg);
  border: 1px dashed var(--color-border);
  border-radius: var(--radius-sm);
  padding: var(--space-4);
  text-align: center;
}

.entry-block {
  padding: var(--space-4) 0;
  border-top: 1px solid var(--color-border);
}

.entry-block:first-of-type {
  border-top: none;
  padding-top: 0;
}

.entry-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: var(--space-3);
}

.entry-label {
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--color-accent);
}
</style>
