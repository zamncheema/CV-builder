<script setup>
// RESPONSIBILITY: display resume data. Nothing else.
//
// This is a pure, read-only component. It receives the full resume
// object through a single Prop and renders it. It never emits
// anything and never changes the data — that keeps the "who is
// allowed to write state" rule completely unambiguous: only the
// Builder forms write, only the Preview reads.

defineProps({
  resume: {
    type: Object,
    required: true
  }
})

function formatRange(start, end) {
  if (!start && !end) return ''
  return [start, end].filter(Boolean).join(' — ')
}
</script>

<template>
  <article id="resume-print-area" class="resume-sheet card">
    <header class="resume-header">
      <h1 class="resume-name">{{ resume.personal.fullName || 'Your Name' }}</h1>
      <p class="resume-title" v-if="resume.personal.jobTitle">{{ resume.personal.jobTitle }}</p>

      <div class="resume-contact">
        <span v-if="resume.personal.email">{{ resume.personal.email }}</span>
        <span v-if="resume.personal.phone">{{ resume.personal.phone }}</span>
        <span v-if="resume.personal.location">{{ resume.personal.location }}</span>
      </div>
    </header>

    <section v-if="resume.personal.summary" class="resume-section">
      <h2 class="section-title">Summary</h2>
      <p class="summary-text">{{ resume.personal.summary }}</p>
    </section>

    <section v-if="resume.experience.length" class="resume-section">
      <h2 class="section-title">Experience</h2>
      <div v-for="entry in resume.experience" :key="entry.id" class="resume-entry">
        <div class="entry-top">
          <h3 class="entry-title">{{ entry.role || 'Role' }} · {{ entry.company || 'Company' }}</h3>
          <span class="entry-dates">{{ formatRange(entry.startDate, entry.endDate) }}</span>
        </div>
        <p v-if="entry.description" class="entry-description">{{ entry.description }}</p>
      </div>
    </section>

    <section v-if="resume.education.length" class="resume-section">
      <h2 class="section-title">Education</h2>
      <div v-for="entry in resume.education" :key="entry.id" class="resume-entry">
        <div class="entry-top">
          <h3 class="entry-title">
            {{ entry.degree || 'Degree' }}<span v-if="entry.field"> in {{ entry.field }}</span>
          </h3>
          <span class="entry-dates">{{ formatRange(entry.startDate, entry.endDate) }}</span>
        </div>
        <p v-if="entry.school" class="entry-description">{{ entry.school }}</p>
      </div>
    </section>

    <section v-if="resume.skills.length" class="resume-section">
      <h2 class="section-title">Skills</h2>
      <ul class="skills-list">
        <li v-for="entry in resume.skills" :key="entry.id" class="skill-chip">
          {{ entry.name || 'Skill' }}<span class="skill-level"> · {{ entry.level }}</span>
        </li>
      </ul>
    </section>

    <p
      v-if="
        !resume.personal.fullName &&
        !resume.experience.length &&
        !resume.education.length &&
        !resume.skills.length
      "
      class="empty-resume"
    >
      Nothing to preview yet. Head to the Builder to add your details.
    </p>
  </article>
</template>

<style scoped>
.resume-sheet {
  padding: var(--space-7);
  max-width: 780px;
  margin: 0 auto;
}

.resume-header {
  border-bottom: 2px solid var(--color-accent);
  padding-bottom: var(--space-4);
  margin-bottom: var(--space-5);
}

.resume-name {
  font-size: 2rem;
  margin-bottom: 4px;
}

.resume-title {
  color: var(--color-accent);
  font-weight: 600;
  font-size: 1rem;
  margin-bottom: var(--space-3);
}

.resume-contact {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-1) var(--space-4);
  font-size: 0.85rem;
  color: var(--color-slate);
}

.resume-section {
  margin-bottom: var(--space-5);
}

.section-title {
  font-size: 0.78rem;
  font-weight: 700;
  letter-spacing: 0.08em;
  text-transform: uppercase;
  color: var(--color-accent);
  margin-bottom: var(--space-3);
}

.summary-text {
  font-size: 0.94rem;
  color: var(--color-ink-soft);
  line-height: 1.65;
}

.resume-entry {
  margin-bottom: var(--space-4);
}

.resume-entry:last-child {
  margin-bottom: 0;
}

.entry-top {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-3);
  margin-bottom: 2px;
}

.entry-title {
  font-size: 0.98rem;
  font-weight: 600;
}

.entry-dates {
  font-size: 0.8rem;
  color: var(--color-slate);
  white-space: nowrap;
}

.entry-description {
  font-size: 0.88rem;
  color: var(--color-ink-soft);
  line-height: 1.6;
}

.skills-list {
  list-style: none;
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  padding: 0;
  margin: 0;
}

.skill-chip {
  background: var(--color-accent-soft);
  color: var(--color-accent-dark);
  font-size: 0.82rem;
  font-weight: 500;
  padding: 5px 12px;
  border-radius: 999px;
}

.skill-level {
  opacity: 0.75;
}

.empty-resume {
  text-align: center;
  color: var(--color-slate);
  font-size: 0.92rem;
  padding: var(--space-6) 0;
}

@media (max-width: 640px) {
  .resume-sheet {
    padding: var(--space-5);
  }
  .entry-top {
    flex-direction: column;
    gap: 2px;
  }
}
</style>
