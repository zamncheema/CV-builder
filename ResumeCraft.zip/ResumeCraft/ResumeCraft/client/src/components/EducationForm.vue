<script setup>
// RESPONSIBILITY: collect education details. Nothing else.
//
// "entries" is the list owned by the parent. Each input reads its
// value directly from that prop, so it always shows the parent's
// real data. Typing emits 'update-entry' with the entry's id and the
// new field values; the "Add" and "Remove" buttons emit 'add-entry'
// and 'remove-entry'. The parent is the only one that actually
// changes resumeData.education.

const props = defineProps({
  entries: {
    type: Array,
    required: true
  }
})

const emit = defineEmits(['add-entry', 'update-entry', 'remove-entry'])

function handleFieldChange(entry, field, value) {
  emit('update-entry', entry.id, { ...entry, [field]: value })
}
</script>

<template>
  <div class="card form-card">
    <div class="form-header">
      <div>
        <h2 class="form-title">Education</h2>
        <p class="form-hint">Your degrees, starting with the most recent.</p>
      </div>
      <button type="button" class="btn btn-secondary btn-sm" @click="emit('add-entry')">
        + Add education
      </button>
    </div>

    <p v-if="entries.length === 0" class="empty-state">
      No education added yet. Click "Add education" to create your first entry.
    </p>

    <div v-for="entry in entries" :key="entry.id" class="entry-block">
      <div class="entry-header">
        <span class="entry-label">Education entry</span>
        <button type="button" class="btn btn-ghost btn-sm" @click="emit('remove-entry', entry.id)">
          Remove
        </button>
      </div>

      <div class="field-row">
        <div class="field-group">
          <label>School / University</label>
          <input
            type="text"
            placeholder="University of the Punjab"
            :value="entry.school"
            @input="handleFieldChange(entry, 'school', $event.target.value)"
          />
        </div>
        <div class="field-group">
          <label>Degree</label>
          <input
            type="text"
            placeholder="BSc Software Engineering"
            :value="entry.degree"
            @input="handleFieldChange(entry, 'degree', $event.target.value)"
          />
        </div>
      </div>

      <div class="field-row">
        <div class="field-group">
          <label>Field of study</label>
          <input
            type="text"
            placeholder="Software Engineering"
            :value="entry.field"
            @input="handleFieldChange(entry, 'field', $event.target.value)"
          />
        </div>
        <div class="field-row">
          <div class="field-group">
            <label>Start date</label>
            <input
              type="text"
              placeholder="Sep 2022"
              :value="entry.startDate"
              @input="handleFieldChange(entry, 'startDate', $event.target.value)"
            />
          </div>
          <div class="field-group">
            <label>End date</label>
            <input
              type="text"
              placeholder="Jun 2026"
              :value="entry.endDate"
              @input="handleFieldChange(entry, 'endDate', $event.target.value)"
            />
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.form-card {
  padding: var(--space-6);
}

.form-header {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
  margin-bottom: var(--space-5);
}

.form-title {
  font-size: 1.2rem;
  margin-bottom: var(--space-1);
}

.form-hint {
  color: var(--color-slate);
  font-size: 0.85rem;
}

.empty-state {
  color: var(--color-slate);
  font-size: 0.88rem;
  background: var(--color-bg);
  border: 1px dashed var(--color-border);
  border-radius: var(--radius-sm);
  padding: var(--space-4);
  text-align: center;
}

.entry-block {
  padding: var(--space-4) 0;
  border-top: 1px solid var(--color-border);
}

.entry-block:first-of-type {
  border-top: none;
  padding-top: 0;
}

.entry-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-bottom: var(--space-3);
}

.entry-label {
  font-size: 0.75rem;
  font-weight: 600;
  letter-spacing: 0.04em;
  text-transform: uppercase;
  color: var(--color-accent);
}
</style>
