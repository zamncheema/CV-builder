import { reactive } from 'vue'
import api from '../services/api'

// SINGLE SOURCE OF TRUTH
// This object is created once, when this module is first imported.
// Because ES modules are cached, every component that imports this
// file gets a reference to the SAME reactive object. That's what
// lets the Builder page and the Preview page share live data even
// though they are different routes. No Pinia, no provide/inject —
// just one shared reactive object.
const resumeData = reactive({
  personal: {
    fullName: '',
    jobTitle: '',
    email: '',
    phone: '',
    location: '',
    summary: ''
  },
  education: [],
  experience: [],
  skills: []
})

// The MongoDB id of the resume this app is working with. We don't
// need the user to ever see or manage this — the composable just
// keeps track of it internally so it knows which document to update.
let resumeId = null

let nextId = 1
function generateId() {
  return nextId++
}

// Every save from this point on sends the request to Express instead
// of writing to Local Storage. If the id isn't known yet (the very
// first load hasn't finished), we simply skip the save — there's
// nothing to update yet.
async function saveToServer() {
  if (!resumeId) return

  try {
    await api.updateResume(resumeId, resumeData)
  } catch (error) {
    // The backend being unreachable shouldn't crash the app — the
    // user can keep editing, we just log what went wrong.
    console.error('Could not save the resume to the server:', error.message)
  }
}

// Ask the backend for the saved resume when the app first starts.
// Called once from App.vue's onMounted(). If MongoDB already has a
// resume, we load it into our reactive object. If not, we create an
// empty one so there's always something to update later.
async function loadResumeData() {
  try {
    const resumes = await api.getResumes()

    let resume = resumes[0]
    if (!resume) {
      resume = await api.createResume(resumeData)
    }

    resumeId = resume._id
    resumeData.personal = { ...resumeData.personal, ...resume.personal }
    resumeData.education = resume.education || []
    resumeData.experience = resume.experience || []
    resumeData.skills = resume.skills || []

    // Keep future generated ids ahead of anything already saved.
    const allIds = [
      ...resumeData.education.map((item) => item.id),
      ...resumeData.experience.map((item) => item.id),
      ...resumeData.skills.map((item) => item.id)
    ]
    if (allIds.length) {
      nextId = Math.max(...allIds) + 1
    }
  } catch (error) {
    console.error('Could not load the resume from the server:', error.message)
  }
}

// PERSONAL INFO
function updatePersonalInfo(updatedPersonal) {
  resumeData.personal = { ...updatedPersonal }
  saveToServer()
}

// EDUCATION
function addEducation() {
  resumeData.education.push({
    id: generateId(),
    school: '',
    degree: '',
    field: '',
    startDate: '',
    endDate: ''
  })
  saveToServer()
}

function updateEducation(id, updatedEntry) {
  const index = resumeData.education.findIndex((item) => item.id === id)
  if (index !== -1) {
    resumeData.education[index] = { ...updatedEntry, id }
    saveToServer()
  }
}

function removeEducation(id) {
  resumeData.education = resumeData.education.filter((item) => item.id !== id)
  saveToServer()
}

// EXPERIENCE
function addExperience() {
  resumeData.experience.push({
    id: generateId(),
    company: '',
    role: '',
    startDate: '',
    endDate: '',
    description: ''
  })
  saveToServer()
}

function updateExperience(id, updatedEntry) {
  const index = resumeData.experience.findIndex((item) => item.id === id)
  if (index !== -1) {
    resumeData.experience[index] = { ...updatedEntry, id }
    saveToServer()
  }
}

function removeExperience(id) {
  resumeData.experience = resumeData.experience.filter((item) => item.id !== id)
  saveToServer()
}

// SKILLS
function addSkill() {
  resumeData.skills.push({
    id: generateId(),
    name: '',
    level: 'Intermediate'
  })
  saveToServer()
}

function updateSkill(id, updatedEntry) {
  const index = resumeData.skills.findIndex((item) => item.id === id)
  if (index !== -1) {
    resumeData.skills[index] = { ...updatedEntry, id }
    saveToServer()
  }
}

function removeSkill(id) {
  resumeData.skills = resumeData.skills.filter((item) => item.id !== id)
  saveToServer()
}

// Every component that calls useResumeData() gets the same reactive
// object plus the same set of functions to safely change it.
export function useResumeData() {
  return {
    resumeData,
    loadResumeData,
    updatePersonalInfo,
    addEducation,
    updateEducation,
    removeEducation,
    addExperience,
    updateExperience,
    removeExperience,
    addSkill,
    updateSkill,
    removeSkill
  }
}
