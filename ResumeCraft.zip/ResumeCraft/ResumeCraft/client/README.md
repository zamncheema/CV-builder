# ResumeCraft — Professional Resume Builder

A small, clean Vue 3 + Vite application for building a resume: fill in
one form, watch a live preview update beside it, and export it to PDF
when it's ready. Built as a university semester project, deliberately
kept to fundamentals-level Vue rather than advanced patterns.

## Running the project

```bash
npm install
npm run dev
```

Then open the URL Vite prints (usually `http://localhost:5173`).

To create a production build:

```bash
npm run build
npm run preview
```

## How it's put together

```
src/
  components/
    NavBar.vue            – navigation only
    PersonalInfoForm.vue  – collects name/contact/summary
    EducationForm.vue     – collects a list of education entries
    ExperienceForm.vue    – collects a list of work experience entries
    SkillsForm.vue        – collects a list of skills
    ResumePreview.vue     – read-only rendering of the resume
  views/
    HomeView.vue          – landing page ("/")
    BuilderView.vue       – the form + live preview ("/builder")
    PreviewView.vue       – full-page preview + PDF export ("/preview")
  composables/
    useResumeData.js      – the single source of truth for resume data
  router/
    index.js              – three routes: home, builder, preview
  styles/
    main.css              – design tokens, resets, shared classes, print rules
```

### Where the data lives

`useResumeData.js` creates one `reactive()` object the first time the
file is imported. Because JavaScript modules are cached, every
component that calls `useResumeData()` gets a reference to that same
object — that's what lets the Builder page and the Preview page share
live data even though they're different routes. It is *not* Pinia,
Vuex, or an event bus; it's just "a module only runs once."

As of Deliverable 2, the resume is stored in MongoDB instead of Local
Storage. `App.vue` calls `loadResumeData()` in `onMounted()`, which
asks the Express backend (`src/services/api.js`) for the saved resume
and fills `resumeData` with the response. Every `update…`/`add…`/
`remove…` function still changes `resumeData` directly and then calls
`saveToServer()`, which sends the whole updated resume back to the
backend with a `PUT` request. See the root `README.md` for the full
client → server → MongoDB flow.

### How data flows through components

Every form component is a one-way street in each direction:

- **Props down** — the parent (`BuilderView`) hands each form the
  slice of `resumeData` it's responsible for.
- **Emits up** — when the user types, the form emits an event with
  the new value. It never edits the prop it was given directly.
- The parent's event handler (from the composable) is the only code
  that actually writes to `resumeData`.
- The updated value flows back down through the prop on the next
  render, which is what the input displays.

`ResumePreview.vue` only ever reads — it has no emits at all, which
keeps "who's allowed to write" unambiguous.

### Routing

- `/` – marketing/landing page
- `/builder` – the editable form with a live side-by-side preview
- `/preview` – a full-page, print-ready preview with an "Export as
  PDF" button (`window.print()`, styled with `@media print` so only
  the resume itself is printed)
